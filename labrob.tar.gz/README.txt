Labyrinth Robot
Copyright © 2016 Nitika Kumar, Ormir Gjurgjej. All rights reserved.

labrob DATEINAME [-t1] [–t2] [–t3]...[-tN] [-h]

t1 ... Wall Follower
t2 ... Tremaux
t3 ... Recursive